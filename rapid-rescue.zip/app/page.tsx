"use client"

import  from "../js/main"

export default function SyntheticV0PageForDeployment() {
  return < />
}